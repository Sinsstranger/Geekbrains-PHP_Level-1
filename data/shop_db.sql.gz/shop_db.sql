-- Adminer 4.8.1 MySQL 5.5.5-10.6.5-MariaDB-1:10.6.5+maria~focal dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `basket`;
CREATE TABLE `basket` (
  `id_basket` int(10) NOT NULL AUTO_INCREMENT,
  `id_good` int(10) NOT NULL DEFAULT 0,
  `id_order` int(10) DEFAULT NULL,
  `id_user` int(10) NOT NULL DEFAULT 0,
  `price` int(10) NOT NULL DEFAULT 0,
  `is_in_order` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_basket`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `basket` (`id_basket`, `id_good`, `id_order`, `id_user`, `price`, `is_in_order`) VALUES
(2,	1,	6,	1,	100,	1),
(3,	1,	NULL,	2,	100,	0),
(5,	1,	1,	1,	100,	1),
(6,	1,	6,	1,	100,	1),
(7,	1,	6,	1,	100,	1),
(8,	1,	NULL,	1,	100,	0);

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id_book` int(10) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_book`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `books` (`id_book`, `book_name`) VALUES
(1,	'Война и мир'),
(2,	'PHP и MySQL'),
(3,	'Электросети для чайников');

DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `id_employee` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT '',
  `middle_name` varchar(255) DEFAULT '',
  `last_name` varchar(255) DEFAULT '',
  PRIMARY KEY (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `employee` (`id_employee`, `first_name`, `middle_name`, `last_name`) VALUES
(1,	'Сергей',	'Иванович',	'Иванов'),
(3,	'Петр',	'Петрович',	'Петров');

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `id_feedback` int(10) NOT NULL AUTO_INCREMENT,
  `feedback_body` text DEFAULT NULL,
  `feedback_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_feedback`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='`id_feedback`, `feedback_body`, `feedback_user`';

INSERT INTO `feedback` (`id_feedback`, `feedback_body`, `feedback_user`) VALUES
(1,	'Тест456',	'Тестовый отзыв123'),
(6,	'My feedback',	'My name'),
(7,	'Тест123',	'Тестовый отзыв123'),
(8,	'Review test',	'Review_test');

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id_good` int(10) NOT NULL AUTO_INCREMENT,
  `good_name` varchar(50) DEFAULT NULL,
  `good_description` varchar(50) DEFAULT NULL,
  `good_price` int(10) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_good`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `goods` (`id_good`, `good_name`, `good_description`, `good_price`, `is_active`) VALUES
(1,	'Носки',	NULL,	100,	1);

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id_menu` int(10) NOT NULL AUTO_INCREMENT,
  `menu_item_name` varchar(255) NOT NULL DEFAULT '',
  `menu_item_link` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `menu` (`id_menu`, `menu_item_name`, `menu_item_link`) VALUES
(1,	'Главная',	'/'),
(2,	'Новости',	'/news/'),
(3,	'Каталог',	'/catalog/'),
(4,	'Контакты',	'/contacts/');

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id_news` int(10) NOT NULL AUTO_INCREMENT,
  `news_title` varchar(50) DEFAULT NULL,
  `news_preview` varchar(50) DEFAULT NULL,
  `news_content` text DEFAULT NULL,
  PRIMARY KEY (`id_news`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `news` (`id_news`, `news_title`, `news_preview`, `news_content`) VALUES
(1,	'Новость 1',	'Тест',	'Тестовая новость'),
(2,	'Новость 2',	'Текст превью',	'Новость 2');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id_order` int(10) NOT NULL AUTO_INCREMENT,
  `id_user` int(10) NOT NULL DEFAULT 0,
  `amount` int(10) NOT NULL DEFAULT 0,
  `id_status` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `orders` (`id_order`, `id_user`, `amount`, `id_status`) VALUES
(1,	1,	550,	2),
(6,	1,	300,	1);

DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `id_picture` int(10) NOT NULL AUTO_INCREMENT,
  `picture_source` varchar(255) NOT NULL DEFAULT '',
  `picture_title` varchar(255) NOT NULL DEFAULT '',
  `picture_alt` varchar(255) NOT NULL DEFAULT '',
  `click` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_picture`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `picture` (`id_picture`, `picture_source`, `picture_title`, `picture_alt`, `click`) VALUES
(1,	'car.jpg',	'Автомобиль',	'Автомобиль',	2),
(2,	'car.jpg',	'Автомобиль 2',	'Автомобиль 2',	0);

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id_role` int(10) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `role` (`id_role`, `role_name`) VALUES
(1,	'Администратор'),
(2,	'Модератор');

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id_status` int(10) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `status` (`id_status`, `status_name`) VALUES
(1,	'Новый заказ'),
(2,	'Заказ принят'),
(3,	'Заказ отправлен'),
(4,	'Заказ выкуплен'),
(5,	'Заказ отменен'),
(6,	'Тестовый заказ');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL DEFAULT '0',
  `user_login` varchar(50) NOT NULL DEFAULT '0',
  `user_password` text NOT NULL,
  `user_last_action` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='INSERT INTO `user` (`id_user`, `user_name`, `user_login`, `user_password`, `user_last_action`) VALUES\r\n	(1, ''admin'', ''admin'', ''$2a$08$ZDYxOGU5ODA0YTk3M2Y1YugWWmWSZ0TTigwlFqe7TePdk6KanN5WS'', ''0000-00-00 00:00:00'');';

INSERT INTO `user` (`id_user`, `user_name`, `user_login`, `user_password`, `user_last_action`) VALUES
(1,	'Sinstranger',	'admin',	'$2a$08$ZDYxOGU5ODA0YTk3M2Y1YuYUlCg7Eue2UcBHDY82lkW/8jYEesuZ.login',	'0000-00-00 00:00:00');

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `id_user_role` int(10) NOT NULL AUTO_INCREMENT,
  `id_role` int(10) NOT NULL DEFAULT 0,
  `id_user` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_user_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `user_role` (`id_user_role`, `id_role`, `id_user`) VALUES
(1,	1,	1),
(2,	2,	1);

-- 2022-01-12 10:21:04
