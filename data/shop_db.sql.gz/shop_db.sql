-- Adminer 4.8.1 MySQL 5.5.5-10.6.5-MariaDB-1:10.6.5+maria~focal dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `photogallery`;
CREATE TABLE `photogallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(256) NOT NULL,
  `opened_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `photogallery` (`id`, `path`, `opened_count`) VALUES
(1,	'/assets/images/dist/photogallery/horrable-road.jpg',	1),
(2,	'/assets/images/dist/photogallery/woodland.jpg',	3);

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID отзыва',
  `author` varchar(255) NOT NULL COMMENT 'Автор отзыва',
  `author_email` varchar(255) NOT NULL COMMENT 'Почта автора',
  `body` varchar(500) NOT NULL COMMENT 'Текст отзыва',
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp() COMMENT 'Дата отзыва',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `reviews` (`id`, `author`, `author_email`, `body`, `date`) VALUES
(1,	'Майор Бухайло',	'buxailo@mail.ru',	'Очень годный сайт, помог мне прикупить несколько годных вещей!!!',	'2022-01-02 20:30:34');

-- 2022-01-12 10:27:24
